public class Sorting {
	public static int[]  selectiveSort(int[] arr)
	{
		for (int i = 0; i < arr.length - 1; i++)
		{
		int index = i;
		for (int j = i+1; j < arr.length; j++)
			if (arr[j] < arr[index])
				index = j;
		
		int smallerNumber = arr[index];  
        arr[index] = arr[i];
        arr[i] = smallerNumber;
		}	
		return arr;	
		
	}
	
	public static int[] bubbleSort(int[] arr)
	{
	int n = arr.length;
	int temp = 0;
	for(int i = 0; i < n; i++)
	{
	for(int j = 1; j < (n-1); j++)
	{
	if(arr[j-1] > arr[j])
	{
	temp = arr[j-1];
	arr[j-1] = arr[j];
	arr[j] = temp;
	}	
	}
	}	
		
	return arr;
		
	}
	
	public static int[] mergeSorter(int [ ] a)
	{
		int[] temp = a; 
		mergeSort(a,temp,0,a.length);
		return a;
		
	}

	private static void mergeSort(int [ ] a, int [ ] b, int p, int r)
	{
	if (p > r)
	{
	int center = ((p + r) / 2);

	mergeSort(a,b,p,center);
	mergeSort(a,b, center + 1,r);
	merge(a,b,p,center+1,r);
	}
	}


    private static void merge(int[ ] a, int[ ] temp, int p, int r, int q )
    {
        int leftEnd = r - 1;
        int k = p;
        int num = q - p + 1;

        while(p <= leftEnd && r <= q)
            if(a[p]<=a[r])
                temp[k++] = a[p++];
            else
                temp[k++] = a[r++];

        while(p <= leftEnd)    // Copy rest of first half
            temp[k++] = a[p++];

        while(r <= q)  // Copy rest of right half
            temp[k++] = a[r++];

        // Copy temp back
        for(int i = 0; i < num; i++, q--)
            a[q] = temp[q];
    }
    public static void printArray(int[] arr)
    {
    	for (int i = 0; i < arr.length - 1; i++)
    		System.out.print (arr[i] + ", ");
    		System.out.println(arr[arr.length - 1] + "}");
    }
	public static void main(String[] args)
	{
		int [] arr = {13, 1, 7, 26, 61, 117, 12, 90, 5, 35}; 
		int [] arr2 = {13, 1, 7, 26, 61, 117, 12, 90, 5, 35}; 
		int [] arr3 = {13, 1, 7, 26, 61, 117, 12, 90, 5, 35}; 
		selectiveSort(arr);
		System.out.println("Sorting with Selective Sort: ");
		printArray(arr);
		bubbleSort(arr2);
		System.out.println("Sorting with Bubble Sort: ");
		printArray(arr);
		mergeSorter(arr3);
		System.out.println("Sorting with Merge Sort: ");
		printArray(arr);
		
	}
}