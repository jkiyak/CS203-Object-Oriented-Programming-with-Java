
public class Bed {
private String bedType;
private int numberofpillows;



public Bed(String type, int pillows)
{
bedType = type;
numberofpillows = pillows;
}

public Bed()
{
	
}

public String getBedType()
{
return bedType;	
}

public int getPillows()
{
return numberofpillows;	
}

public void setBedType(String type)
{
bedType = type;	
}

public void setPillows(int pillows)
{
numberofpillows = pillows;	
}

public void printBed()
{
System.out.println("You will have a bed of type " + this.getBedType() + ".");
System.out.println("You will have " + this.getPillows() + " pillows.");
}
}
