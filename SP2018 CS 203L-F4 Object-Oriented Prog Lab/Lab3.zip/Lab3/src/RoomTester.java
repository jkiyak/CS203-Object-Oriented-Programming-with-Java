public class RoomTester {
	public static void main(String[] args)
	{
		String F = "booked";
		boolean B = true;
		int R = 800;
		Bed Test = new Bed(F, B, R);
		String N1 = "Tom Brady";
	
		
		boolean B1 = false;
		int R = 900;
		Bed Test1 = new Bed(N1, H1, W1, Num1);
		
		String N2 = "Rob Gronkowski";
		int H2= 78;
		double W2 = 265;
		int Num2 = 87;
		Bed Test2 = new Bed(N2, H2, W2, Num2);
		Bed[] TeamTest = {Test, Test1, Test2};
		Team Tester = new Team("Tester Team", TeamTest);
		Tester.printTeam();
		
	}

}

