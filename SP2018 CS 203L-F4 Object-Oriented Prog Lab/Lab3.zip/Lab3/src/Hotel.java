
public class Hotel {

}
