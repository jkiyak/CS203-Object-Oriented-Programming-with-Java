
public class Room {
	public boolean roombooked;
	public Bed[] bedsarray;
	public int numberofbeds;
	public int numberofroom;
	public Room()
	{
		
	}
	
	public Room(Bed[] beds, boolean booked, int roomnumber)
	{
		bedsarray = beds;
	    roombooked = booked;	
	    numberofroom = roomnumber;
	    numberofbeds = bedsarray.length;
	}
	
	public Bed[] getBeds()
	{
		return bedsarray;
	}
	public int getroomnumber()
	{
		return numberofroom;
	}
	public void setRoomNumber(int roomnumber)
	{
		numberofroom = roomnumber;
	}
	public void bookedorno (boolean booked)
	{
	if (booked = true)
	{
	booked = true;	
	}	
	else
	{
	booked = false;	
	}
	}
	public void setBeds(Bed[] beds)
	{
		bedsarray = beds;
		numberofbeds = bedsarray.length;
	}
	public void printTeam()
	{
		System.out.println("Room Number: " + this.getroomnumber() + " \n");
		Bed[] Team = this.getBeds();
		for(int i = 0; i < this.(); i++)
		{
			
			Team[i].printBed();
		}
	}

}

