
public class BedTester {
	public static void main(String[] args)
	{
		String T = "twin";
		int P = 8;
		Bed Test = new Bed(T,P);
		Test.printBed();
		Test.setBedType("ur mum");
		Test.setPillows(15);
		Test.printBed();
	}

}
