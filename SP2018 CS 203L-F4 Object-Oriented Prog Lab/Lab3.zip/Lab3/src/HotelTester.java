
public class HotelTester {

}
