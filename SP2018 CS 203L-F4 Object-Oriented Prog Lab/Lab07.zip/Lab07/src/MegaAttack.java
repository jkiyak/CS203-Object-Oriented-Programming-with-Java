import edu.uab.cs203.Objectmon;
import edu.uab.cs203.attacks.BasicAttack;

//check to see if the objectmon is evolved.
//if evolved, then double the attack.


public class MegaAttack extends BasicAttack {

private MegaObjectmon e;
	
public MegaAttack() {
super();
}

public MegaAttack(Objectmon belongsTo, String name) {
super(belongsTo, name);	
}

public int getDamage(Objectmon other)
{
if (other.getClass().equals(e.getClass())) {
e = (MegaObjectmon)other;
if (e.isEvolved()) {
return (other.getWeight()/5)*2;	
}

}
return other.getWeight() / 5;
}
}
