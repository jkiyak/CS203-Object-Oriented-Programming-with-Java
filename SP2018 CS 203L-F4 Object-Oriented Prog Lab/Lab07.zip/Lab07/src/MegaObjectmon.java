import edu.uab.cs203.Evolvable;
import edu.uab.cs203.lab06.Filemon;

//objectmon itself.
//
public class MegaObjectmon extends Filemon implements Evolvable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4064997365560441399L;
	private boolean evolved;
	private int attackCount;

	public MegaObjectmon(String name, boolean evolved){
	super(name);
	this.setEvolved(evolved);
	}
	
	public MegaObjectmon(String name, int hp, int stamina, int weight, boolean evolved){
		
	super(name, hp, stamina, weight);
	this.setEvolved(evolved);
	}
	
	public void devolve() {
		if (attackCount == 5){
			this.setHp(getHP() / 2);
			this.setStamina(getStamina() / 2);
			attackCount = 0;
		}
	}

	public void evolve() {
		while(attackCount < 3){
		super.nextAttack();
		attackCount++;
		
		while (attackCount >= 3) {
		this.setHp(getHP() * 2);
		this.setStamina(getStamina() * 2);
		attackCount++;
		}
		}
	}

	public boolean isEvolved() {
		return evolved;
	}

	public void setEvolved(boolean evolved) {
		this.evolved = evolved;
	}

}
