import java.util.List;
import java.util.Scanner;
import java.util.StringJoiner;

import edu.uab.cs203.Objectmon;
import edu.uab.cs203.ObjectmonNameGenerator;
import edu.uab.cs203.TrainingGym;

//training gym that works with megaobjectmon.
//setting one team to megaobjectmon and another to objectmon.
public class MegaTrainingGym extends TrainingGym {
	public void configureFight() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("How many Megaobjectmon do you want? ");
        int numObjectmon = scanner.nextInt();

        System.out.println("How many rounds do you want? ");
        int numRounds = scanner.nextInt();

        System.out.println("Number of Megaobjectmon: " + numObjectmon + "\nNumber of rounds: " + numRounds + "\nIs this correct? (yes/no)");
        String correct = scanner.next();
        scanner.close();
        if (correct.equalsIgnoreCase("yes")) {
                createRandomTeams(numObjectmon);
            fight(numRounds);
        }
        System.exit(1);

    }

    @Override
    public boolean isWinner() {
        return !(canTeamAFight() && canTeamBFight());
    }

    @SuppressWarnings("unchecked")
	@Override
    public void createRandomTeams(int i) {
        for (int j = 0; j < i; j++) {
            getTeamA().add(new Objectmon(ObjectmonNameGenerator.nextName()));
            getTeamB().add(new Objectmon(ObjectmonNameGenerator.nextName()));
        }

    }

    @Override
    public String toString() {
        StringJoiner sj = new StringJoiner(",", "{", "}");
        sj.add("Team A: " + toStringTeam(getTeamA()));
        sj.add("\nTeam B: " + toStringTeam(getTeamB()));
        return sj.toString();
    }

    @Override
    public boolean canTeamAFight() {
        return canFight(getTeamA());
    }

    @Override
    public boolean canTeamBFight() {
        return canFight(getTeamB());
    }

    protected String toStringTeam(List<MegaObjectmon> list) {
        StringJoiner sj = new StringJoiner(",", "{", "}");
        for (MegaObjectmon megaobjectmon: list) {
            sj.add(megaobjectmon.toString());
        }
        System.out.println(sj);
        return sj.toString();
    }

    @SuppressWarnings("unchecked")
	@Override
    public boolean addToTeamB(Objectmon objectmon) {
        return getTeamB().add(objectmon);
    }

    @SuppressWarnings("unchecked")
	@Override
    public boolean addToTeamA(Objectmon objectmon) {
        return getTeamA().add(objectmon);
    }
}

