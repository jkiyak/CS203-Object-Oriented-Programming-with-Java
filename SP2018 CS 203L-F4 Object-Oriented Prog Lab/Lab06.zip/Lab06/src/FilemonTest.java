import java.io.IOException;

public class FilemonTest {

	public static void main(String[] args) throws IOException {
	Filemon jerry = new Filemon("jerry", 80, 20, 20);
	String path = "filemontext.txt";
	jerry.save(path);
	jerry = jerry.load(path);
	System.out.println(jerry.toString());
	}




}
