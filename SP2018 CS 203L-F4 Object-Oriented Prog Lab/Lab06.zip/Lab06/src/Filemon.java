import java.io.BufferedReader;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import edu.uab.cs203.Loadable;
import edu.uab.cs203.Objectmon;
import edu.uab.cs203.Savable;

import java.io.PrintWriter;

public class Filemon extends Objectmon implements Savable, Loadable<Filemon> {

	public Filemon(String name, int HP, int Weight, int Stamina) {
	super(name, HP, Weight, Stamina);	
	}

	public Filemon load(String path) { //returns created objectmon
		String fileName = path;
        // This will reference one line at a time
        	String line = null;

		try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
           Scanner sc = new Scanner(new File(path));
           String input = sc.next();
           //Split / Replace all
           input.split("input", 2);
           input.replaceAll("input", "");
		} catch(IOException e) {
			
		} finally {
		
		}
		return Filemon.this;
          
		
    }
	@SuppressWarnings("resource")
	public boolean save(String path) { //takes filemon and breaks it down into stats and prints out the stats {
		PrintWriter out = null;
		
		try {
			
		out = new PrintWriter(new FileWriter(path));
		out.println(this.toString());
		out.close();
		return true;
		} 
		catch (IOException e) {
		e.printStackTrace();	
		}
		return false;
	}
}
