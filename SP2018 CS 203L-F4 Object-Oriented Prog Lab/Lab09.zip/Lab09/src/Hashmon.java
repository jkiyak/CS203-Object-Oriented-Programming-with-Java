import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import edu.uab.cs203.attacks.AbstractAttack;
import edu.uab.cs203.effects.StatusEffect;
import edu.uab.cs203.lab08.PoisonAttack;
import edu.uab.cs203.lab08.Statusmon;
import edu.uab.cs203.ObjectdexEntry;
import edu.uab.cs203.Objectmon;
import edu.uab.cs203.attacks.*;
import edu.uab.cs203.attacks.BasicAttack;

@SuppressWarnings("serial")
public class Hashmon extends Statusmon {

	public Hashmon(String Name) {
		ObjectdexEntry Stats = pokedex.get(name);
		this.getName();
		if (Stats.getAttackType().equalsIgnoreCase("poison")) {
			List<AbstractAttack> a;
			Object Objectmon;
			AbstractAttack atk = PoisonAttack(pokedex.get(getAttacks()), this.getName());
			a.add(atk);
			this.setAttacks(a);
			}
		}


	private AbstractAttack PoisonAttack(String string, String name) {
		// TODO Auto-generated method stub
		return null;
	}


	public void ObjectDexEntry(String name,int hp, int weight, int Stamina, boolean attackType) {
			StatusEffect effect = null;
			attackType = this.addStatusEffect(effect);
		}
	
	String filePath = "test.txt";
    HashMap<String, String> pokedex = new HashMap<String, String>();

    String line;
    BufferedReader reader = new BufferedReader(new FileReader(filePath));
    {
    while ((line = reader.readLine()) != null)
    {
        String[] parts = line.split(":", 2);
        if (parts.length >= 2)
        {
            String key = parts[0];
            String value = parts[1];
            pokedex.put(key, value);
        } else {
            System.out.println("ignoring line: " + line);
        }
    }

    for (String key : pokedex.keySet())
    {
        System.out.println(key + ":" + pokedex.get(key));
    }
    reader.close();
}
}
