import edu.uab.cs203.Objectmon;
import edu.uab.cs203.ObjectmonNameGenerator;

public class TrainingGymTester extends TrainingGym {

	public static void main(String[] args) {
		TrainingGymTester a = new TrainingGymTester();
		a.configureFight();
		
		

	}

}
