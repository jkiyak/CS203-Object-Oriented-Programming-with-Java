import java.util.List;
import java.util.Scanner;
import java.util.StringJoiner; 

import edu.uab.cs203.AbstractGym;
import edu.uab.cs203.Objectmon;
import edu.uab.cs203.ObjectmonNameGenerator;





public class TrainingGym extends AbstractGym {
		//Can user add objectmon to Team A
		public boolean addToTeamA(Objectmon objectmon) {
		
			List<Objectmon> teamAList = getTeamA();
			
			if (teamAList.add(objectmon)) 
			
			{
			setTeamA(teamAList);
			return true;
		}
			return false;
		}
		
		
		//Can the user add objectmon to Team B
		
		public boolean addToTeamB(Objectmon objectmon) {
			
			List<Objectmon> teamBList = getTeamB();
			if (teamBList.add(objectmon)) {
				setTeamB(teamBList);
				return true;
		}
		return false;
		}	

		//tells whether team A has any objectmon left to fight
		//done
		public boolean canTeamAFight() {
			
			List<Objectmon> teamAList = getTeamA();
			for (int i = 0; i < teamAList.size(); i++) {
				if (!teamAList.get(i).isFeinted()) {
					return true;
				}
			}
			return false;
		}
		

		//tells whether Team B has any objectmon left to fight
		//done
		public boolean canTeamBFight() {
			
			
			List<Objectmon> teamBList = getTeamB();
			for (int i = 0; i < teamBList.size(); i++) {
				if (!teamBList.get(i).isFeinted()) {
					return true;
				}
			}
			return false;
			
		}

		//configures fight with max number of rounds, objectmon per team
		//done
		public void configureFight() {
			
			Scanner rounds = new Scanner(System.in);
			System.out.println("Enter your max number of rounds you want to fight with: ");
			int r = rounds.nextInt();
			
			Scanner objectmon = new Scanner(System.in);
			System.out.println("Enter the number of Objectmon for each team: ");
			int o = objectmon.nextInt();
			
			Scanner confirmFight = new Scanner(System.in);
			System.out.println("Are you sure these are the settings you want? ");
			String c = confirmFight.next();
			if(c.equalsIgnoreCase("yes"))
			{
				createRandomTeams(o);
				fight(r);	
			}
			else {
			
				System.exit(0);
			}
			confirmFight.close();
			
			
			
		}
		//pulls random names and creates Objectmon to put into teams A and B
		public void createRandomTeams(int o) {
			
			List<Objectmon> teamAList = getTeamA();
			List<Objectmon> teamBList = getTeamB();
			
			for (int i = 0; i < o; i++) {
				Objectmon objectmonA = new Objectmon(ObjectmonNameGenerator.nextName());
				
				Objectmon objectmonB = new Objectmon(ObjectmonNameGenerator.nextName());
				
			
				teamAList.add(objectmonA);
				teamBList.add(objectmonB); 
			}
			
		}

		//returns true if one team cannot fight, false if both still have members
		//is it better to check canTeamBFight/AFight etc. or this method?
		public boolean isWinner() {
			if (canTeamAFight() == true && canTeamBFight() == true) {
	
			return false;
		}
			return true;
		} 
		
		
		@Override
		protected String toStringTeam(List<Objectmon> team) {
			StringJoiner ap = new StringJoiner(",");
			for(int i = 0; i <team.size(); i++)
			{
			ap.add(team.get(i).toString());
			}
			String result = ap.toString();
			return result;
		}

		@Override
		public String toString() {
			StringJoiner sj = new StringJoiner(" ");
			sj.add("The Objectmon on Team A are:");
			sj.add(toStringTeam(this.getTeamA()));
			sj.add("and Team B has:");
			sj.add(toStringTeam(this.getTeamB()));
			String answer = sj.toString();
			return answer;
		}

		
}