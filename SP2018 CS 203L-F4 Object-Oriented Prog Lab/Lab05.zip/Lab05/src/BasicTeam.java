import edu.uab.cs203.AbstractGym;
import edu.uab.cs203.TrainingGym;
import edu.uab.cs203.Team;
import edu.uab.cs203.ObjectmonNameGenerator;
import edu.uab.cs203.Objectmon; 
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.ArrayList;

public class BasicTeam<E extends Objectmon> implements Team {
	private String name;
	private int MaxSize;
	private List<E> team;
	
	
	public BasicTeam(String Name, int size) {
		
		this.name = Name;
		this.MaxSize = size;
		this.team = new ArrayList<E>(); 
	
	}
	
	public boolean canFight() {
		for(int i = 0; i < this.team.size(); i++) {
			if(!team.get(i).isFainted()) {
				return true;
			}
		}
		return false;
		}
	
	
	public int getMaxSize() {
		return MaxSize;
		
	}
	
	public void setMaxSize(int size) {
		MaxSize = size; 
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String Name) {
		name = Name;
		
	}

	@Override
	public boolean add(Object e) {
		if(this.team.size() < getMaxSize()) {
			return true;
			
		}
		return false; 
	}

	
	@Override
	public void add(int index, Object element) {
		this.team.add(index, (E) element);
		
		
	}

	@Override
	public boolean addAll(Collection c) {
		return this.team.addAll(c);
	}

	
	@Override
	public boolean addAll(int size, Collection c) {
		return this.team.addAll(c);
	}

	@Override
	public void clear() {
		this.team.clear();
		
	}

	@Override
	public boolean contains(Object o) {
		return this.team.contains(o);
	}

	@Override
	public boolean containsAll(Collection c) {
		return this.team.containsAll(c);
	}

	@Override
	public Object get(int index) {
		return this.team.get(index);
	}

	@Override
	public int indexOf(Object o) {
		return this.team.indexOf(o);
	}

	@Override
	public boolean isEmpty() { 
		return this.team.isEmpty();
		
	}

	@Override
	public Iterator iterator() {
		return this.team.iterator();
	}

	@Override
	public int lastIndexOf(Object o) {
		return this.team.lastIndexOf(o);
	}

	@Override
	public ListIterator listIterator() {
		return this.team.listIterator();
		
	}

	@Override
	public ListIterator listIterator(int index) {
		return this.team.listIterator(index);
	}

	@Override
	public boolean remove(Object o) {
		return this.team.remove(o);
	}

	@Override
	public Object remove(int e) {
		return this.team.remove(e);
		
	}

	@Override
	public boolean removeAll(Collection c) {
		return this.team.removeAll(c);
	}

	@Override
	public boolean retainAll(Collection c) {
		return this.team.retainAll(c);
	}

	@Override
	public Object set(int index, Object element) {
		return this.team.set(index, (E) element);
		 
		
	}

	@Override
	public int size() {
		return this.team.size();
	}

	@Override
	public List subList(int fromIndex, int toIndex) {
		return this.team.subList(fromIndex, toIndex);
	}

	@Override
	public Object[] toArray() {
		return this.team.toArray();
		
	}

	@Override
	public Object[] toArray(Object[] a) {
		return this.team.toArray(a);
		
	}

	@Override
	public Objectmon nextObjectmon() {
		for(int i = 0; i < this.team.size(); i++) {
			if(!this.team.get(i).isFainted()) {
				return this.team.get(i);
			}
		}
		return null;
		
		
	}


}

