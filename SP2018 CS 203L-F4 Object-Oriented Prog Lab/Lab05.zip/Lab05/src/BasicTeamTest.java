package edu.uab.cs203.lab05.test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.*;

import edu.uab.cs203.Objectmon;
import edu.uab.cs203.Named;

/*****************************************************************************/
// YOU DON'T HAVE THIS! IF YOU WANT TO USE THIS TEST CASE, YOU NEED TO
// EITHER CHANGE THIS TO POINT TO YOUR TEAM CLASS OR NAME YOUR TEAM CLASS
// THE SAME AS I DID!
import edu.uab.cs203.Lab05.BasicTeam;
/*****************************************************************************/

import edu.uab.cs203.Team;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * Unit test for simple App.
 */
public class BasicTeamTest {

  private Team<Objectmon> team1;
  private Team<Objectmon> team2;
  private Team<Objectmon> team3;
  private Team<Objectmon> team4;
  private Team<Objectmon> team5;

  private Objectmon testmon1;
  private Objectmon testmon2;
  private Objectmon testmon3;
  private Objectmon testmon4;
  private Objectmon testmon5;

  @BeforeEach
  void init() {

    // YOU MUST CHANGE ALL THE INSTANTIATIONS TO WHATEVER YOU NAMED YOUR CLASS!
    team1 = new BasicTeam<>();
    team1.setName("Team 1");
    team1.setMaxSize(5);

    team2 = new BasicTeam<>();
    team2.setName("Team 2");
    team2.setMaxSize(5);

    team3 = new BasicTeam<>();
    team3.setName("Team 3");
    team3.setMaxSize(5);

    team4 = new BasicTeam<>();
    team4.setName("Team 4");
    team4.setMaxSize(5);

    team5 = new BasicTeam<>();
    team5.setName("Team 5");
    team5.setMaxSize(5);

    testmon1 = new Objectmon("testmon1");
    testmon2 = new Objectmon("testmon2");
    testmon3 = new Objectmon("testmon3");
    testmon4 = new Objectmon("testmon4");
    testmon5 = new Objectmon("testmon5");

  }
  
  @DisplayName("The Named interface should be properly implemented")
  @Test
  void testName() {

    assertTrue(team1 instanceof Named, "team1 is not an instance of Named?!?!");
    String name = "test name";

    team1.setName(name);
    assertEquals(name, team1.getName());
    assertEquals("test name", team1.getName());
  }

  @Test
  void testMaxSize() {
    // I did not enforce any particular constructors on you
    // so I'm trying to make these tests more generic
    int originalMaxSize = team1.getMaxSize();

    team1.setMaxSize(100);
    assertEquals(100, team1.getMaxSize());
    

    team1.setMaxSize(originalMaxSize);
    assertEquals(originalMaxSize, team1.getMaxSize());
    
    // Not sure if maybe this testing should be in the test for add()
    // or maybe its own test all together?
    team1.setMaxSize(1);
    
    assertTrue(team1.add(testmon1));
    
    assertFalse(team1.add(testmon2));
    
    team1.setMaxSize(2);
    assertTrue(team1.add(testmon2));
  }

  @Test
  void testNextObjectmon() {
    testmon1 = new Objectmon("testmon1", 10, 1, 0);
    testmon2 = new Objectmon("testmon2", 0, 1, 0);
    testmon3 = new Objectmon("testmon3", 0, 1, 0);

    team1.add(testmon1);
    team1.add(testmon2);
    assertEquals(testmon1, team1.nextObjectmon());

    // to avoid this test being dependent on clear(),
    // we will just create a new team
    team1 = new BasicTeam<Objectmon>(null, 0);
    team1.setMaxSize(2);
    team1.add(testmon2);
    team1.add(testmon1);
    assertEquals(testmon1, team1.nextObjectmon());
    
    team1 = new BasicTeam<Objectmon>(null, 0);
    team1.setMaxSize(2);
    team1.add(testmon2);
    team1.add(testmon3);
    assertNull(team1.nextObjectmon());
  }

  @Test
  void testCanFight() {
    assertFalse(team1.canFight());

    team1.add(new Objectmon("testmon1", 0, 0, 0));
    assertFalse(team1.canFight());

    team1.add(new Objectmon("testmon2"));
    assertTrue(team1.canFight());
  }

  @Test
  void testSize() {
    assertEquals(0, team1.size());
    

    
    team1.add(testmon1);
    assertEquals(1, team1.size());
    

    // this is testing two methods at once kinda
    // not the greatest, but there are dependencies
    // between methods sometiems...
    team1.remove(testmon1);
    assertEquals(0, team1.size());
  }

  @Test
  void testIsEmpty() {
    assertTrue(team1.isEmpty());

    team1.add(testmon1);
    assertFalse(team1.isEmpty());

    team1.remove(testmon1);
    assertTrue(team1.isEmpty());
  }

  @Test
  void testContains() {

    assertFalse(team1.contains(testmon1));

    team1.add(testmon1);
    assertTrue(team1.contains(testmon1));

    assertFalse(team1.contains(null));
  }

  @Test
  void testIterator() {

    team1.add(testmon1);
    team1.add(testmon2);

    Iterator<Objectmon> it = team1.iterator();

    int count = 0;
    while (it.hasNext()) {
      Objectmon o = it.next();
      assertEquals(o, team1.get(count));
      count++;
    }

    assertEquals(2, count);
  }

  @Test
  void testToArray() {

    Object[] a1 = {testmon1, testmon2, testmon3};

    team1.add(testmon1);
    team1.add(testmon2);
    team1.add(testmon3);
    assertArrayEquals(a1, team1.toArray());

    Objectmon[] a2 = {testmon1, testmon2, testmon3};
    assertArrayEquals(a2, team1.toArray(a2));
  }

  @Test
  void testRemove() {
    team1.add(testmon1);
    
    assertTrue(team1.remove(testmon1));
    assertFalse(team1.remove(testmon1));
  }

  List<Objectmon> genObjectmonList() {
    List<Objectmon> list = new ArrayList<>();
    list.add(testmon1);
    list.add(testmon2);
    list.add(testmon3);

    return list;
  }

  @Test
  void testContainsAll() {
    
    List<Objectmon> list = genObjectmonList();
    
    team1.add(testmon1);
    assertFalse(team1.containsAll(list));

    team1.add(testmon3);
    team1.add(testmon2);
    assertTrue(team1.containsAll(list));
  }

  @SuppressWarnings("unchecked")
@Test
  void testAddAll() {
    
    List<Objectmon> list = genObjectmonList();
    
    team1.addAll(list);

    assertEquals(list.size(), team1.size());
    assertTrue(team1.containsAll(list));

    team1 = new BasicTeam<Objectmon>(null, 0);
    team1.setName("Basic Team");
    team1.setMaxSize(5);
    

    team1.add(testmon4);
    team1.add(testmon5);
    team1.addAll(0, list);

    assertEquals(list.get(0), team1.get(0));
    assertEquals(testmon5, team1.get(team1.size() - 1));
  }

  @Test
  void testRemoveAll() {
    List<Objectmon> list = genObjectmonList();

    team1.add(testmon1);
    team1.add(testmon2);
    team1.add(testmon3);

    team1.removeAll(list);

    assertTrue(team1.isEmpty());
  }

  @Test
  void retainAll() {
    List<Objectmon> list = genObjectmonList();
    team1.add(testmon1);
    team1.add(testmon2);
    team1.add(testmon3);
    team1.add(testmon4);
    team1.add(testmon5);

    assertTrue(team1.retainAll(list));

    assertEquals(3, team1.size());

    assertFalse(team1.contains(testmon4));

    assertFalse(team1.contains(testmon5));

    assertFalse(team1.retainAll(list));

  }


  @Test
  void testClear() {
    team1.add(testmon1);
    assertEquals(1, team1.size());

    team1.clear();

    assertEquals(0, team1.size());
    assertTrue(team1.isEmpty());
    assertFalse(team1.contains(testmon1));
  }

  @Test
  void testEquals() {
    team1.add(testmon1);
    team1.add(testmon2);
    team1.add(testmon3);
    team1.setName("A");

    team2.add(testmon1);
    team2.add(testmon2);
    team2.add(testmon3);
    team2.setName("A");

    team3.add(testmon1);
    team3.add(testmon2);
    team3.add(testmon3);
    team3.setName("A");

    team4.add(testmon3);
    team4.add(testmon2);
    team4.add(testmon1);
    team4.setName("A");

    team5.add(testmon1);
    team5.add(testmon2);
    team5.add(testmon3);
    team5.setMaxSize(1000);

    // reflexiv
    assertEquals(team1, team1);

    // symetric
    assertEquals(team1, team2);
    assertEquals(team2, team1);

    // transitive
    assertEquals(team1, team3);
    assertEquals(team3, team2);

    // is equals assuring that the team name must be equal?
    team2.setName("B");
    assertNotEquals(team1, team2);

    assertNotEquals(team1, team4);
    assertNotEquals(team4, team1);
    assertNotEquals(team1, team5);

    // check to make sure that this is a true equivalence relationship
    // and not a partial ordering
    // Thanks JF for this!

    team1.clear();
    team1.setName("Partial Ordering Test Team");
    team1.setMaxSize(3);
    team1.add(testmon1);
    team1.add(testmon2);
    team1.add(testmon3);

    team4.clear();
    team4.setName("Partial Ordering Test Team");
    team4.setMaxSize(3);
    team4.add(testmon1);
    team4.add(testmon2);

    assertNotEquals(team1, team4);
    assertNotEquals(team4, team1);

    // Check to make sure that it works on other objects
    assertNotEquals(team1, "test string");
    assertNotEquals("test string", team1);


  }

  @Test
  void testGet() {
    team1.add(testmon1);
    assertEquals(testmon1, team1.get(0));
  }

  @Test
  void testSet() {
    team1.add(testmon1);
    team1.add(testmon2);
    team1.add(testmon3);

    Objectmon tmp = team1.set(1, testmon4);
    assertEquals(testmon2, tmp);
    assertEquals(testmon4, team1.get(1));
  }


  @Test
  void testAdd() {
    assertFalse(team1.contains(testmon1));
    assertTrue(team1.add(testmon1));
    assertTrue(team1.contains(testmon1));

    team1.setMaxSize(1);
    assertFalse(team1.add(testmon2));
    assertFalse(team1.contains(testmon2));

    team1.setMaxSize(2);
    assertTrue(team1.add(testmon2));
    assertTrue(team1.contains(testmon2));
  }

  @Test
  void testIndexOf() {
    assertEquals(team1.indexOf("String"), -1);
    assertEquals(team1.indexOf(testmon1), -1);

    team1.add(testmon1);
    team1.add(testmon2);
    team1.add(testmon1);

    assertEquals(0, team1.indexOf(testmon1));
    assertEquals(1, team1.indexOf(testmon2));
  }

  @Test
  void testLastIndexOf() {
    team1.add(testmon1);
    team1.add(testmon1);

    assertEquals(1, team1.lastIndexOf(testmon1));
  }

  @Test
  void testListIterator() {
    team1.add(testmon1);
    team1.add(testmon2);
    team1.add(testmon3);
    team1.add(testmon4);

    ListIterator<Objectmon> lit = team1.listIterator();

    assertFalse(lit.hasPrevious());
    assertTrue(lit.hasNext());

    assertEquals(-1, lit.previousIndex());
    assertEquals(0, lit.nextIndex());

    assertEquals(testmon1, lit.next());
    assertTrue(lit.hasPrevious());
    assertEquals(testmon1, lit.previous());

    lit = team1.listIterator(1);
    assertEquals(testmon2, lit.next());
    assertEquals(testmon3, lit.next());
    assertEquals(testmon3, lit.previous());
    assertEquals(testmon3, lit.next());
    assertEquals(testmon4, lit.next());
    assertFalse(lit.hasNext());
  }

  @Test
  void subList() {
    team1.add(testmon1);
    team1.add(testmon2);
    team1.add(testmon3);
    team1.add(testmon4);
    team1.add(testmon5);


    List<Objectmon> list = team1.subList(1, 3);

    assertTrue(team1.containsAll(list));

    assertEquals(2, list.size());
    assertEquals(testmon2, list.get(0));
    assertEquals(testmon3, list.get(1));

    assertTrue(team1.subList(1, 1).isEmpty());

  }

}
