import edu.uab.cs203.Objectmon;
import edu.uab.cs203.effects.AbstractStatusEffect;

public class BadlyPoisoned extends AbstractStatusEffect {

	int turncounter;
	public BadlyPoisoned(int numTicks, Objectmon affectedObjectmon) {
		super(numTicks, affectedObjectmon);
		// TODO Auto-generated constructor stub
	}
	public void tick() {
	super.tick();
	int currentweight = getAffectedObjectmon().getWeight();
	int currentHP = getAffectedObjectmon().getHP();
	double poisondamage = currentweight / 16;
	double totaldamage = currentHP - poisondamage;
	if (turncounter > 0) {
	totaldamage = currentHP - poisondamage;
	} else {
	totaldamage = currentHP - (poisondamage * 2);
	}
	
	}
	
	@Override
	public boolean preventAttack() {
		return false;
	}
}
