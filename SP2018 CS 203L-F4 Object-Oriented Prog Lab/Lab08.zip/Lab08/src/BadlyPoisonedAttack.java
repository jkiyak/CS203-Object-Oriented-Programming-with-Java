import java.util.Random;

import edu.uab.cs203.Objectmon;
import edu.uab.cs203.attacks.BasicAttack;
import edu.uab.cs203.effects.StatusEffect;

public class BadlyPoisonedAttack extends BasicAttack {
	
	private StatusEffect A;
	


	public BadlyPoisonedAttack(Objectmon other, String name) {
		BadlyPoisoned eff = new BadlyPoisoned(3, other);
		A = eff;
	}

	public StatusEffect getStatusEffect(Objectmon other) {
	return A;	
		
	}
	}
