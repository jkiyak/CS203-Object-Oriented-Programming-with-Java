import edu.uab.cs203.Objectmon;
import edu.uab.cs203.attacks.BasicAttack;
import edu.uab.cs203.effects.StatusEffect;

public class PoisonedAttack extends BasicAttack {
	private StatusEffect A;
	


	public PoisonedAttack(Objectmon other, String name) {
		Poisoned eff = new Poisoned(3, other);
		A = eff;
	}

	public StatusEffect getStatusEffect(Objectmon other) {
	return A;	
		
	}
	}
