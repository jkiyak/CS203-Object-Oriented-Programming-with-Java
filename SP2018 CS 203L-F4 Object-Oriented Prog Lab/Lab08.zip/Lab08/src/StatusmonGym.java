import java.util.*;
import edu.uab.cs203.TrainingGym;
import edu.uab.cs203.Team;
import edu.uab.cs203.lab05.BasicTeam;
import edu.uab.cs203.Objectmon;
import edu.uab.cs203.ObjectmonNameGenerator;

public class StatusmonGym extends TrainingGym {

  public StatusmonGym(Team teamA, Team teamB) {
    super(teamA, teamB);
  }

  public StatusmonGym() {
    super();
  }

  public static void main( String[] args ){
    // System.out.println("Welcome to the Statusmon Training Gym!");
    StatusmonGym gym = new StatusmonGym(new BasicTeam<Statusmon>("Team A", 5), new BasicTeam<Statusmon>("Team B", 5));
    gym.configureFight();
    gym.fight(gym.getMaxRounds());
  }

  public String toString() {
    StringJoiner sj = new StringJoiner(",", "{", "}");
    sj.add(toStringTeam(getTeamA()));
    sj.add(toStringTeam(getTeamB()));

    return sj.toString();

  }

  public void configureFight() {
    Scanner scanner = new Scanner(System.in);

    System.out.println("How many Statusmon per team?");
    int numPerTeam = scanner.nextInt();

    System.out.println("How many rounds?");
    int maxRounds = scanner.nextInt();

    System.out.println("Do you want to continue? Anything besides 'yes' will exit");
    String choice = scanner.next();

    if (!choice.equals("yes")) {
      System.exit(1);
    }

    createRandomTeams(numPerTeam);
    setMaxRounds(maxRounds);

  }


  private boolean checkA() {
    return true;
  }

  protected String toStringTeam(Team team) {
    return team.toString();
    // StringJoiner sj = new StringJoiner(",", "[", "]");
    // for (Statusmon o : team) {
    //   sj.add(o.toString());
    // }
    // return "{" + "\"" + getName() +  "\"" + ", " + sj.toString() + "}";
  }

  public boolean addToTeamA(Statusmon Statusmon) {
    return getTeamA().add(Statusmon);
  }
  public boolean addToTeamB(Statusmon Statusmon) {
    return (getTeamB().add(Statusmon));
  }

  public boolean canTeamAFight() {
    return canFight(getTeamA());
  }

  public boolean canTeamBFight() {
    return canFight(getTeamB());
    // for (Statusmon o : getTeamB()) {
    //   if (o.getHP() < 1) {
    //     return false
    //   }
    // }

    // return true;
  }

  public boolean isWinner() {
    return !(canFight(getTeamA()) && canFight(getTeamB()));
  }

  @Override
  public void createRandomTeams(int n) {

    for (int i = 0; i < n; i++) {
      addToTeamA(new Statusmon(ObjectmonNameGenerator.nextName()));
    }

    for (int i = 0; i < n; i++) {
      addToTeamB(new Statusmon(ObjectmonNameGenerator.nextName()));
    }

  }


}