import edu.uab.cs203.attacks.AbstractAttack;
import edu.uab.cs203.lab06.Filemon;

@SuppressWarnings("serial")
public class Statusmon extends Filemon {

	public Statusmon() {
	super();
	}
	
	public Statusmon(String name) {
	super(name);
	}
	
	public Statusmon(String name, int hp, int stamina, int weight) {
	super(name, hp, stamina, weight);	
	}
	
	public AbstractAttack nextAttack() {
	return super.nextAttack();
		
	}
	
	public void tick() {
	this.tick();
	}
	
}
