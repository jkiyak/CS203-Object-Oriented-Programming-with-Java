import edu.uab.cs203.Objectmon;
import edu.uab.cs203.effects.AbstractStatusEffect;

public class Poisoned extends AbstractStatusEffect {
	
	public Poisoned(int numTicks, Objectmon affectedObjectmon) {
		super(numTicks, affectedObjectmon);
		// TODO Auto-generated constructor stub
	}

	public void tick() {
		super.tick();
		int currentweight = getAffectedObjectmon().getWeight();
		int currentHP = getAffectedObjectmon().getHP();
		double poisondamage = currentweight / 8;
		double totaldamage = currentHP - poisondamage;
	}

	
	@Override
	public boolean preventAttack() {
		return false;
	}
}
