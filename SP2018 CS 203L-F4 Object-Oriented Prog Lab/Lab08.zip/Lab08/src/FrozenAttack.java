import edu.uab.cs203.Objectmon;
import edu.uab.cs203.attacks.BasicAttack;
import edu.uab.cs203.effects.StatusEffect;

public class FrozenAttack extends BasicAttack {

private StatusEffect A;

public FrozenAttack(Objectmon other, String name) {
	Frozen eff = new Frozen(3, other);
	A = eff;
}

public StatusEffect getStatusEffect(Objectmon other) {
return A;	
	
}
}
