import edu.uab.cs203.Objectmon;
import edu.uab.cs203.attacks.BasicAttack;
import edu.uab.cs203.effects.StatusEffect;

public class ParalyzedAttack extends BasicAttack {
	
	private StatusEffect A;
	


	public ParalyzedAttack(Objectmon other, String name) {
		Paralyzed eff = new Paralyzed(3, other);
		A = eff;
	}

	public StatusEffect getStatusEffect(Objectmon other) {
	return A;	
		
	}
	}
