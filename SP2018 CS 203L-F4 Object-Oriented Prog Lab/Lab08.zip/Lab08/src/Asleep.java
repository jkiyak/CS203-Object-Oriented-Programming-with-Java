import edu.uab.cs203.Objectmon;
import edu.uab.cs203.Tickable;
import edu.uab.cs203.effects.AbstractStatusEffect;

public class Asleep extends AbstractStatusEffect implements Tickable {

	public Asleep(int numTicks, Objectmon affectedObjectmon) {
		super(numTicks, affectedObjectmon);
	}

	public void tick() {
	super.tick();
	}
	
	@Override
	public boolean preventAttack() {
	return true;
	}

}
