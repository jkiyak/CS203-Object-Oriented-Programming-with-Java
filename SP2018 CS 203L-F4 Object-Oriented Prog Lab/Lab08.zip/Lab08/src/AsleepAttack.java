
import java.util.Random;

import edu.uab.cs203.Objectmon;
import edu.uab.cs203.attacks.BasicAttack;
import edu.uab.cs203.effects.StatusEffect;

public class AsleepAttack extends BasicAttack {
	
	private StatusEffect A;
	
	Random rand = new Random();
	int numTicks = rand.nextInt((7 - 1) + 1) + 1;
	
	public AsleepAttack(Objectmon other, String name) {
		Asleep eff = new Asleep(numTicks, other);
		A = eff;
	}

	public StatusEffect getStatusEffect(Objectmon other) {
	return A;	
		
	}
	}
