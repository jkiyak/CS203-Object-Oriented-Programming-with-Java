import edu.uab.cs203.Objectmon;
import edu.uab.cs203.effects.AbstractStatusEffect;
import java.math.*;

public class Frozen extends AbstractStatusEffect {

	public Frozen(int numTicks, Objectmon affectedObjectmon) {
		super(numTicks, affectedObjectmon);
	}
	public void tick() {
	super.tick();
	}
	
	@Override
	public boolean preventAttack() {
		int rand = (int) (Math.random() *100);
		if (rand > 0 && rand < 20) {
		return false;
		}else {
		return true;	
		}

	}
}
